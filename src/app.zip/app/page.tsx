import Hero from "@/app/components/Hero";
// import Phases from "@/app/components/Phases";
// import Experts from "@/app/components/Experts";
// import ContactCTA from "@/app/components/ContactCTA";

export default function Home() {
  return (
    <div className="space-y-16">
      <Hero />

      
    </div>
  );
}
